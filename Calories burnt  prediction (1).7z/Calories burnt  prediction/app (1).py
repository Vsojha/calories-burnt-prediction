{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "0a22b3b4-6c12-4bed-ac26-915d87fa9e7d",
   "metadata": {},
   "outputs": [],
   "source": [
    "from flask import Flask, request, render_template\n",
    "import pickle\n",
    "import numpy as np\n",
    "\n",
    "# Load the trained model, encoder, and scaler\n",
    "with open('calories_model.pkl', 'rb') as f:\n",
    "    data = pickle.load(f)\n",
    "    model = data['model']\n",
    "    encoder = data['encoder']\n",
    "    scaler = data['scaler']\n",
    "\n",
    "app = Flask(__name__)\n",
    "\n",
    "@app.route('/')\n",
    "def home():\n",
    "    return render_template('index.html')\n",
    "\n",
    "@app.route('/predict', methods=['POST'])\n",
    "def predict():\n",
    "    try:\n",
    "        # Collect input values from the form\n",
    "        gender = request.form['gender']\n",
    "        age = float(request.form['age'])\n",
    "        height = float(request.form['height'])\n",
    "        weight = float(request.form['weight'])\n",
    "        duration = float(request.form['duration'])\n",
    "        heart_rate = float(request.form['heart_rate'])\n",
    "        body_temp = float(request.form['body_temp'])\n",
    "\n",
    "        # Ensure valid gender input\n",
    "        if gender not in ['female', 'male']:\n",
    "            return render_template('result.html', prediction_text=\"Invalid gender. Please select 'female' or 'male'.\")\n",
    "\n",
    "        # Preprocess the input features\n",
    "        gender_encoded = encoder.transform([[gender]])[0][0]\n",
    "        input_features = np.array([[gender_encoded, age, height, weight, duration, heart_rate, body_temp]])\n",
    "        input_scaled = scaler.transform(input_features)\n",
    "\n",
    "        # Make prediction\n",
    "        prediction = model.predict(input_scaled)[0]\n",
    "\n",
    "        # Return the prediction\n",
    "        return render_template('result.html', prediction_text=f\"Your Total Calories Burnt is: {prediction:.2f} calories\")\n",
    "\n",
    "    except Exception as e:\n",
    "        print(f\"Error: {e}\")  # Log error for debugging\n",
    "        return render_template('result.html', prediction_text=\"An error occurred. Please check your input values.\")\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "70bdaec0-ca0d-491e-aa69-2ae07645aba1",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Flask app is running! Access it at http://127.0.0.1:5000/\n",
      " * Serving Flask app '__main__'\n",
      " * Debug mode: on\n"
     ]
    },
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.\n",
      " * Running on http://127.0.0.1:5000\n",
      "Press CTRL+C to quit\n",
      "127.0.0.1 - - [23/Nov/2024 13:32:53] \"GET / HTTP/1.1\" 200 -\n",
      "127.0.0.1 - - [23/Nov/2024 16:05:26] \"GET / HTTP/1.1\" 200 -\n",
      "C:\\Users\\HP\\anaconda3\\Lib\\site-packages\\sklearn\\base.py:439: UserWarning: X does not have valid feature names, but OrdinalEncoder was fitted with feature names\n",
      "  warnings.warn(\n",
      "C:\\Users\\HP\\anaconda3\\Lib\\site-packages\\sklearn\\base.py:439: UserWarning: X does not have valid feature names, but StandardScaler was fitted with feature names\n",
      "  warnings.warn(\n",
      "127.0.0.1 - - [23/Nov/2024 16:07:58] \"POST /predict HTTP/1.1\" 200 -\n",
      "127.0.0.1 - - [23/Nov/2024 16:08:06] \"GET / HTTP/1.1\" 200 -\n",
      "C:\\Users\\HP\\anaconda3\\Lib\\site-packages\\sklearn\\base.py:439: UserWarning: X does not have valid feature names, but OrdinalEncoder was fitted with feature names\n",
      "  warnings.warn(\n",
      "C:\\Users\\HP\\anaconda3\\Lib\\site-packages\\sklearn\\base.py:439: UserWarning: X does not have valid feature names, but StandardScaler was fitted with feature names\n",
      "  warnings.warn(\n",
      "127.0.0.1 - - [23/Nov/2024 16:11:42] \"POST /predict HTTP/1.1\" 200 -\n",
      "127.0.0.1 - - [23/Nov/2024 16:11:47] \"GET / HTTP/1.1\" 200 -\n",
      "C:\\Users\\HP\\anaconda3\\Lib\\site-packages\\sklearn\\base.py:439: UserWarning: X does not have valid feature names, but OrdinalEncoder was fitted with feature names\n",
      "  warnings.warn(\n",
      "C:\\Users\\HP\\anaconda3\\Lib\\site-packages\\sklearn\\base.py:439: UserWarning: X does not have valid feature names, but StandardScaler was fitted with feature names\n",
      "  warnings.warn(\n",
      "127.0.0.1 - - [23/Nov/2024 16:12:42] \"POST /predict HTTP/1.1\" 200 -\n",
      "127.0.0.1 - - [23/Nov/2024 16:12:51] \"GET / HTTP/1.1\" 200 -\n"
     ]
    }
   ],
   "source": [
    "import threading\n",
    "\n",
    "# Function to run the Flask app\n",
    "def run_app():\n",
    "    app.run(port=5000, debug=True, use_reloader=False)\n",
    "\n",
    "# Run Flask app in a separate thread\n",
    "thread = threading.Thread(target=run_app)\n",
    "thread.daemon = True\n",
    "thread.start()\n",
    "\n",
    "print(\"Flask app is running! Access it at http://127.0.0.1:5000/\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "af429010-c80b-4433-992d-0ffde0eb5544",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
